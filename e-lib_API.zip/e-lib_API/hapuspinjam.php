<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);
$host = 'localhost';
$db = 'e_perpus';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
echo json_encode(array("success" => false, "error" => "Connection failed: " .
$conn->connect_error));
exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// Retrieve POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);
if (!$data) {
echo json_encode(array("success" => false, "error" => "Invalid JSON
received"));
exit();
}
$book_id = isset($data['id_buku']) ? $data['id_buku'] : null;
if (!$book_id) {
echo json_encode(array("success" => false, "error" => "Book ID not
provided"));
exit();
}
$conn->autocommit(FALSE); // Turn off auto-commit
// Delete from peminjaman table
$sql_delete = "DELETE FROM peminjaman WHERE id_buku = ?";
$stmt_delete = $conn->prepare($sql_delete);
if ($stmt_delete) {
$stmt_delete->bind_param("i", $book_id);
$stmt_delete->execute();
$stmt_delete->close();
} else {

echo json_encode(array("success" => false, "error" => "Failed to prepare
delete statement"));
exit();
}
// Update buku status
$sql_update = "UPDATE buku SET status_peminjaman = 'Tersedia' WHERE
id_buku = ?";
$stmt_update = $conn->prepare($sql_update);
if ($stmt_update) {
$stmt_update->bind_param("i", $book_id);
$stmt_update->execute();
$stmt_update->close();
} else {
echo json_encode(array("success" => false, "error" => "Failed to prepare
update statement"));
exit();
}
$conn->commit(); // Commit the transaction
$conn->autocommit(TRUE); // Turn on auto-commit again
echo json_encode(array("success" => true));
} else {

echo json_encode(array("success" => false, "error" => "Invalid request
method"));
}
$conn->close();
?>