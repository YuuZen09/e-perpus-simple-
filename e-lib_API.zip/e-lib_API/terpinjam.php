<?php
header('Content-Type: application/json');
// No need for error reporting in production, handle errors gracefully instead
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
$host = 'localhost';
$db = 'e_perpus';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
// Send a proper JSON error response
http_response_code(500); // Internal Server Error
echo json_encode(array("error" => "Connection failed: " . $conn->connect_error));
exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

// Retrieve POST data (more secure way)
$data = json_decode(file_get_contents('php://input'), true);
$user_id = $data['id_user'] ?? null; // PHP 7+ null coalescing operator
if (!$user_id) {
http_response_code(400); // Bad Request
echo json_encode(array("error" => "User ID not provided"));
exit();
}
$sql = "SELECT buku.id_buku, buku.judul, buku.pengarang, buku.gambar
FROM peminjaman
JOIN buku ON peminjaman.id_buku = buku.id_buku
WHERE peminjaman.id_user = ?";
$stmt = $conn->prepare($sql);
if ($stmt) {
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$borrowedBooks = array();
while ($row = $result->fetch_assoc()) {

$borrowedBooks[] = $row;
}
$stmt->close();
// Send the expected JSON response
echo json_encode(array("books" => $borrowedBooks));
} else {
http_response_code(500); // Internal Server Error
echo json_encode(array("error" => "Failed to prepare statement: " . $conn->error));
}
} else {
http_response_code(405); // Method Not Allowed
echo json_encode(array("error" => "Invalid request method"));
}
$conn->close();