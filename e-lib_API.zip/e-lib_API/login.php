<?php

include 'koneksi.php';
if($_POST){
//Data
$username = $_POST['no_anggota'] ?? '';
$password = $_POST['password'] ?? '';
$response = []; //Data Response
//Cek username didalam databse
$userQuery = $conn->prepare("SELECT * FROM user where no_anggota
= ?");
$userQuery->execute(array($username));
$query = $userQuery->fetch();
if($userQuery->rowCount() == 0){
$response['status'] = false;
$response['message'] = "no_anggota Tidak Terdaftar";
} else {
// Ambil password di db

$passwordDB = $query['password'];
if(strcmp(md5($password),$passwordDB) === 0){
$response['status'] = true;
$response['message'] = "Login Berhasil";
$response['data'] = [
'user_id' => $query['id_user'],
'nama' => $query['nama'],
'no_anggota' => $query['no_anggota']
];
} else {
$response['status'] = false;
$response['message'] = "Password anda salah";
}
}
//Jadikan data JSON
$json = json_encode($response, JSON_PRETTY_PRINT);
//Print
echo $json;
}