<?php
include "config.php";
$conn = new mysqli($servername, $username, $password, $dbname);
$query = mysqli_query($conn, "SELECT * FROM buku");
$json = array();
while ($row = mysqli_fetch_assoc($query)){
$json[] = $row;
}
echo json_encode($json);
mysqli_close($conn);