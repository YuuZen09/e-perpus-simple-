84
<?php
$host = 'localhost';
$db = 'e_perpus';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$id_user = $_POST['id_user'];
$id_buku = $_POST['id_buku'];
try {
// Cek status peminjaman
$queryCekStatus = "SELECT status_peminjaman FROM buku WHERE
id_buku = ?";
$stmtCekStatus = $conn->prepare($queryCekStatus);
$stmtCekStatus->bind_param('i', $id_buku); // bind parameter as integer
$stmtCekStatus->execute();

$resultCekStatus = $stmtCekStatus->get_result();
if ($resultCekStatus->num_rows > 0) {
$statusPeminjaman = $resultCekStatus->fetch_assoc()
['status_peminjaman'];
if ($statusPeminjaman === 'Terpinjam') {
echo json_encode(['status' => 'error', 'message' => 'Buku sedang
dipinjam oleh pengguna lain']);
exit();
} else {
// Update status peminjaman
$queryUpdateBuku = "UPDATE buku SET status_peminjaman =
'Terpinjam' WHERE id_buku = ?";
$stmtUpdateBuku = $conn->prepare($queryUpdateBuku);
$stmtUpdateBuku->bind_param('i', $id_buku); // bind parameter as integer
$stmtUpdateBuku->execute();
// Lakukan proses penyimpanan data peminjaman ke database
$queryInsertPeminjaman = "INSERT INTO peminjaman (id_user,
id_buku) VALUES (?, ?)";
$stmtInsertPeminjaman = $conn->prepare($queryInsertPeminjaman);
$stmtInsertPeminjaman->bind_param('ii', $id_user, $id_buku); // bind parameters as integers

$stmtInsertPeminjaman->execute();
echo json_encode(['status' => 'success', 'message' => 'Buku berhasil
dipinjam']);
}
} else {
echo json_encode(['status' => 'error', 'message' => 'Gagal memeriksa status
peminjaman buku']);
}
} catch (Exception $e) {
echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan: ' . 
$e->getMessage()]);
}
} else {
echo json_encode(['status' => 'error', 'message' => 'Metode request tidak
valid']);
}
?>