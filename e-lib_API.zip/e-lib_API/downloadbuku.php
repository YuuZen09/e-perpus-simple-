<?php
// DownloadBuku.php
$host = 'localhost';
$db = 'e_perpus';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
if (isset($_POST['id_user']) && isset($_POST['id_buku'])) {
$id_user = $_POST['id_user'];
$id_buku = $_POST['id_buku'];
// Cek apakah buku sudah dipinjam oleh user
$queryCekPeminjaman = "SELECT * FROM peminjaman WHERE id_user
= ? AND id_buku = ?";
$stmtCekPeminjaman = $conn->prepare($queryCekPeminjaman);

$stmtCekPeminjaman->bind_param('ii', $id_user, $id_buku); // 'ii' untuk dua integer
$stmtCekPeminjaman->execute();
$resultCekPeminjaman = $stmtCekPeminjaman->get_result();
if ($resultCekPeminjaman && $resultCekPeminjaman->num_rows > 0) {
// Buku sudah dipinjam oleh user, lakukan proses download
// Misalnya, kirimkan path file buku ke aplikasi Android
$queryGetFilePath = "SELECT lokasi_file FROM pdf_files WHERE
id_buku = ?";
$stmtGetFilePath = $conn->prepare($queryGetFilePath);
$stmtGetFilePath->bind_param('i', $id_buku);
$stmtGetFilePath->execute();
$resultGetFilePath = $stmtGetFilePath->get_result();
if ($resultGetFilePath && $resultGetFilePath->num_rows > 0) {
$filePath = $resultGetFilePath->fetch_assoc()['lokasi_file'];
// Kirimkan path file buku ke aplikasi Android
echo json_encode(['status' => 'success', 'lokasi_file' => $filePath]);
} else {
echo json_encode(['status' => 'error', 'message' => 'File buku tidak
ditemukan']);
}
} else {

// Buku belum dipinjam oleh user
echo json_encode(['status' => 'error', 'message' => 'Anda belum meminjam buku ini']);
}
} else {
echo json_encode(['status' => 'error', 'message' => 'ID pengguna atau ID
buku tidak ditemukan dalam permintaan.']);
}
} else {
echo json_encode(['status' => 'error', 'message' => 'Metode request tidak
valid']);
}
?>