<?php
$host = 'localhost';
$db = 'e_perpus';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
if (isset($_GET['id_user']) && isset($_GET['id_buku'])) {
$userId = $_GET['id_user'];
$bookId = $_GET['id_buku'];
try {
// Query untuk memeriksa apakah buku sudah dipinjam oleh pengguna
$queryCheckBorrowStatus = "SELECT * FROM peminjaman WHERE
id_user = ? AND id_buku = ?";
$stmtCheckBorrowStatus = $conn->prepare($queryCheckBorrowStatus);
$stmtCheckBorrowStatus->bind_param('ii', $userId, $bookId); // 'ii' untuk dua integer

$stmtCheckBorrowStatus->execute();
$result = $stmtCheckBorrowStatus->get_result();
if ($result->num_rows > 0) {
// Buku sudah dipinjam oleh pengguna
echo json_encode(['status' => 'borrowed']);
} else {
// Buku belum dipinjam oleh pengguna
echo json_encode(['status' => 'not_borrowed']);
}
} catch (Exception $e) {
// Tangani error
echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan: ' .
$e->getMessage()]);
}
} else {
echo json_encode(['status' => 'error', 'message' => 'ID pengguna atau ID
buku tidak ditemukan dalam permintaan.']);
}
} else {
echo json_encode(['status' => 'error', 'message' => 'Metode request tidak
valid']);
}
?>